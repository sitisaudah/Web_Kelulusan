"use client";
import { motion } from 'framer-motion';
import { CheckCircle2, XCircle, Download, Printer, Share2, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function HasilKelulusan() {
  // Simulasi data dari backend
  const data = {
    nama: "BUDI SETIAWAN",
    nisn: "0081234567",
    kelas: "IX-A",
    status: "LULUS" // Ganti ke "TIDAK LULUS" untuk testing
  };

  const isLulus = data.status === "LULUS";

  return (
    <div className="max-w-2xl mx-auto my-12 px-4">
      <Link href="/cek-kelulusan" className="inline-flex items-center text-blue-600 mb-6 hover:underline">
        <ArrowLeft className="w-4 h-4 mr-1" /> Kembali
      </Link>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-100"
      >
        {/* Header Status */}
        <div className={`p-8 text-center ${isLulus ? 'bg-emerald-500' : 'bg-rose-500'} text-white`}>
          {isLulus ? (
            <CheckCircle2 className="w-20 h-20 mx-auto mb-4" />
          ) : (
            <XCircle className="w-20 h-20 mx-auto mb-4" />
          )}
          <h2 className="text-3xl font-black uppercase tracking-wider">
            {isLulus ? 'Selamat! Anda Lulus' : 'Mohon Tetap Semangat'}
          </h2>
        </div>

        {/* Detail Siswa */}
        <div className="p-8">
          <div className="grid grid-cols-2 gap-4 border-b border-slate-100 pb-6 mb-6">
            <div>
              <p className="text-xs text-slate-400 uppercase font-bold tracking-widest">Nama Lengkap</p>
              <p className="font-bold text-slate-800">{data.nama}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase font-bold tracking-widest">NISN</p>
              <p className="font-bold text-slate-800">{data.nisn}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase font-bold tracking-widest">Kelas</p>
              <p className="font-bold text-slate-800">{data.kelas}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase font-bold tracking-widest">Tahun Ajaran</p>
              <p className="font-bold text-slate-800">2025/2026</p>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button className="flex-1 bg-slate-800 text-white py-3 rounded-xl font-bold flex items-center justify-center hover:bg-slate-900 transition-all">
              <Download className="w-4 h-4 mr-2" /> Surat Kelulusan
            </button>
            <button className="px-4 py-3 border border-slate-200 rounded-xl hover:bg-slate-50 transition-all">
              <Printer className="w-5 h-5 text-slate-600" />
            </button>
            <button className="px-4 py-3 border border-slate-200 rounded-xl hover:bg-slate-50 transition-all">
              <Share2 className="w-5 h-5 text-slate-600" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}