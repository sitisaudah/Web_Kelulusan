"use client";
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Search } from 'lucide-react';

export default function CekKelulusan() {
  const [nisn, setNisn] = useState('');
  const [tglLahir, setTglLahir] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleCheck = (e) => {
    e.preventDefault();
    if (nisn.length < 10) {
      alert("NISN harus 10 digit!");
      return;
    }
    setLoading(true);
    
    // Simulasi loading ke backend
    setTimeout(() => {
      setLoading(false);
      // Pindah ke halaman hasil (data bisa dipasing via query atau state management)
      router.push(`/hasil?nisn=${nisn}`);
    }, 2000);
  };

  return (
    <div className="max-w-md mx-auto my-16 px-4">
      <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-slate-800">CEK HASIL KELULUSAN</h2>
          <p className="text-slate-500">Masukkan data siswa dengan benar</p>
        </div>

        <form onSubmit={handleCheck} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">NISN</label>
            <input
              type="number"
              placeholder="Contoh: 0081234567"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              value={nisn}
              onChange={(e) => setNisn(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Tanggal Lahir</label>
            <input
              type="date"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              value={tglLahir}
              onChange={(e) => setTglLahir(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold flex items-center justify-center hover:bg-blue-700 transition-all disabled:bg-blue-300"
          >
            {loading ? <Loader2 className="animate-spin mr-2" /> : <Search className="mr-2 w-5 h-5" />}
            Lihat Hasil
          </button>
        </form>
      </div>
    </div>
  );
}